export function somar(a: number, b: number) {
    return a + b
}